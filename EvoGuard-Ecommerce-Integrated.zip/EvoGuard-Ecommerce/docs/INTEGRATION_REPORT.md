# EvoGuard E-Commerce Integration Report

## Source Mapping

### `flipkart-mern-master.zip`
Used as the base application. It contains the existing React frontend, Express backend, MongoDB models, cookie/JWT authentication, product management, orders, payments, and admin dashboard.

### `EvoGuard-Sanyam.zip`
Used for the IDS/security core. The stronger modular detector set under `server/security/` was selected instead of the smaller duplicate top-level detector implementation. Integrated signals include SQL injection, XSS, path traversal, suspicious URL, suspicious user-agent/bot, brute-force, request-rate, and admin-enumeration detection.

The uploaded Sanyam server referenced files such as its own middleware/database/logging pieces that were not present in that ZIP, so those references were not copied blindly. Equivalent integration-specific middleware and MongoDB models were created inside the existing commerce backend.

### `EvoGuard-Shalmali.zip`
Used for authentication-security behavior: failed-login tracking, account lockout policy, endpoint-specific rate-limit policy, and security audit concepts. Its separate Express server, separate `User` model, separate database configuration, and Bearer-token API were **not** copied because doing so would duplicate and conflict with the commerce application's existing user/auth system.

## Major Changes

- Added `backend/middlewares/evoGateMiddleware.js` as the unified EvoGuard request gate.
- Added request/session correlation and persistent MongoDB `RiskProfile` state.
- Added central `SecurityLog` model and admin security APIs.
- Added progressive risk with time decay.
- Added a separate five-tier decision engine.
- Added isolated deception routes.
- Adapted the admin-enumeration detector so authenticated EvoMart admins are not false positives.
- Removed `admin` from the generic suspicious-URL detector to prevent double-counting legitimate admin URLs.
- Redacted passwords/tokens/payment secrets before detector input scanning.
- Added account lockout fields to the existing EvoMart user schema.
- Fixed the existing password pre-save hook to `return next()` when the password is unchanged; this is required because failed-login counters are saved without changing the password.
- Added login/registration/admin rate limiting without introducing another dependency.
- Added security event logging to authentication/authorization failures.
- Added browser session tracking through `X-Session-ID`.
- Added an admin Security dashboard page inside the existing admin UI.
- Standardized environment configuration on a root `.env` created from `.env.example`.

## Integration Status

| Component | Status | Notes |
|---|---|---|
| E-commerce application | Integrated | Existing source retained as base |
| EvoGuard middleware | Integrated | Applied before `/api/v1` commerce routes |
| Risk engine | Integrated | Sanyam detector risk + persistent progressive risk |
| Decision engine | Integrated | ALLOW / MONITOR / RATE_LIMIT / REDIRECT / BLOCK |
| Authentication security | Integrated | Lockout, rate limits, audit events adapted to existing auth |
| Behavior monitoring | Not integrated | No behavioral sensor module was present in uploaded ZIPs |
| Honeypot / deception | Integrated | Backend decoy endpoints; does not modify commerce data |
| AI / intelligence service | Not integrated | No Python AI service was present in uploaded ZIPs |
| Admin security dashboard | Integrated | Added to existing admin navigation |

## Test Status

### WORKING / VERIFIED

- 9 security unit tests pass.
- Normal request produces zero rule risk in the detector test fixture.
- SQL injection detection works in the detector test fixture.
- Sensitive password content is redacted before attack-signature scanning.
- Legitimate authenticated admin route is not flagged as admin enumeration.
- Anonymous admin probing is detected.
- Brute-force detector reaches its configured threshold.
- Progressive risk accumulation works.
- Time-based risk decay works.
- All five decision tiers produce the expected action.
- All backend and security test `.js` files pass `node --check`.
- Root `server.js` passes `node --check`.
- `backend/app.js` successfully loads using the original application's dependency set.
- `GET /api/v1/security/health` returned HTTP 200 from the integrated Express app.
- Modified frontend files (`App.js`, `index.js`, session initializer, sidebar, and security dashboard) parse successfully with Babel's parser and JSX enabled.

### NOT TESTED END-TO-END

- Live MongoDB persistence for `RiskProfile` and `SecurityLog`.
- Browser login/register flow against a running MongoDB instance.
- Live Cloudinary uploads.
- Live SendGrid email flows.
- Live payment flows.
- Full production React build in this execution environment.

These require runtime dependencies, database/service credentials, or a configured external environment. No claim is made that those external integrations were exercised here.

### CONFIGURATION REQUIRED

Copy `.env.example` to `.env` and provide the values required for the existing commerce features you intend to run. At minimum a running MongoDB URI and JWT secret are required for normal authenticated operation.

## Cleanup Performed

Excluded from the final project/archive:

- All uploaded `node_modules` directories.
- Existing frontend build output.
- Real `backend/config/config.env` from the source archive.
- `.git` history/directories.
- Duplicate standalone EvoGuard servers.
- Duplicate standalone EvoGuard user/auth database and routes.
- Temporary extraction and test dependency directories.

## Known Limitations

- Request-rate and brute-force detector counters are in-memory; persistent user lockout and progressive risk are MongoDB-backed.
- The fallback session identifier is application-level correlation, not an authentication credential.
- Behavioral and ML risk inputs are currently zero because no corresponding source modules were included in the uploads.
- The deception system is a backend decoy response layer, not a full mirror frontend.
