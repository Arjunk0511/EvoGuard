# EvoGuard E-Commerce Integrated

A cleaned integration of the existing **EvoMart / Flipkart-style MERN e-commerce application** with the uploaded **EvoGuard IDS/risk module** and **EvoGuard authentication-security module**.

The integration preserves the original product, cart, order, payment, user, and admin flows while placing EvoGuard security controls in front of the existing `/api/v1` routes.

## Architecture

```text
React Frontend
    |
    | X-Session-ID
    v
Node / Express Backend
    |
    v
EvoGuard Middleware
    |
    +--> Request ID + Session Resolution
    +--> Rule Detectors
    |      SQLi / XSS / Path Traversal / Suspicious URL
    |      Bot UA / Admin Enumeration / Brute Force / Request Rate
    +--> Persistent Progressive Risk Profile (MongoDB)
    +--> Decision Engine
    |      ALLOW / MONITOR / RATE_LIMIT / REDIRECT / BLOCK
    +--> Security Log (MongoDB)
    |
    v
Existing EvoMart Routes
    |
    v
MongoDB
```

High-risk traffic can be redirected to isolated deception endpoints. The deception handlers return decoy data only and do not modify the real commerce collections.

## Integrated Security Features

- UUID request IDs returned as `X-Request-ID`.
- Session tracking priority: `X-Session-ID` → authenticated user ID → fallback session cookie.
- Frontend session ID stored in `sessionStorage` and automatically attached to Axios requests.
- Sensitive request fields such as passwords, tokens, card numbers, and CVV are redacted before signature scanning.
- SQL injection, XSS, path traversal, suspicious URL, suspicious user-agent, admin enumeration, brute-force, and high request-rate detectors.
- MongoDB-backed progressive risk profiles with configurable time decay.
- Five-tier decision policy:

| Risk | Action |
|---:|---|
| 0–24 | ALLOW |
| 25–49 | MONITOR |
| 50–69 | RATE_LIMIT |
| 70–84 | REDIRECT |
| 85–100 | BLOCK |

- Account lockout after 5 failed password attempts for 15 minutes.
- Login, registration, and admin request rate limits.
- Central security logging for request decisions and authentication events.
- Deception endpoints for fake login, admin, database, and catalogue responses.
- Admin **Security** page showing request totals, interventions, honeypot activity, high-risk sessions, and recent security events.
- Basic security response headers.

## Important Integration Choices

The original e-commerce authentication system was **not replaced**. EvoGuard authentication protections were adapted into the existing `User` model, cookie JWT flow, controller, and admin role model. This avoids creating a second user collection or a second login API.

The uploaded EvoGuard IDS contained an admin-enumeration detector that would also match EvoMart's legitimate `/admin/...` routes. The integrated detector now exempts verified authenticated admins, while anonymous admin probing is still detected.

The uploaded projects did **not** include a Python AI/intelligence service or behavioral-sensor implementation. Those components are therefore not claimed as integrated in this archive.

## Project Structure

```text
EvoGuard-Ecommerce/
├── backend/
│   ├── controllers/
│   ├── middlewares/
│   │   ├── auth.js
│   │   ├── evoGateMiddleware.js
│   │   └── securityHeaders.js
│   ├── models/
│   │   ├── RiskProfile.js
│   │   ├── SecurityLog.js
│   │   └── ...existing commerce models
│   ├── routes/
│   │   ├── deceptionRoute.js
│   │   ├── securityRoute.js
│   │   └── ...existing commerce routes
│   └── security/
│       ├── detectors/
│       ├── authPolicy.js
│       ├── authRateLimiter.js
│       ├── decisionEngine.js
│       ├── progressiveRiskEngine.js
│       ├── riskEngine.js
│       ├── securityLogger.js
│       └── sessionResolver.js
├── frontend/
│   └── src/
│       ├── components/Admin/Security/
│       └── security/session.js
├── tests/security/
├── docs/
├── .env.example
├── package.json
└── server.js
```

## Setup

Requirements:

- Node.js and npm
- MongoDB
- Cloudinary credentials for existing image-upload flows
- SendGrid configuration for existing email flows when those features are used
- Payment credentials when payment functionality is used

Create local configuration from the template:

```powershell
Copy-Item .env.example .env
```

Edit `.env` and provide your own credentials. Never commit the real `.env` file.

Install backend/root dependencies:

```powershell
npm install
```

Install frontend dependencies:

```powershell
npm install --prefix frontend
```

Run backend and frontend together:

```powershell
npm run dev
```

The existing frontend development proxy targets `http://localhost:4000`.

## Security Routes

Public security health check:

```http
GET /api/v1/security/health
```

Admin-only security data:

```http
GET /api/v1/admin/security/summary
GET /api/v1/admin/security/logs?limit=50
```

Deception routes used internally by the decision engine:

```http
/api/v1/deception/login
/api/v1/deception/admin
/api/v1/deception/database
/api/v1/deception/catalog
```

## Existing Commerce APIs

The original API structure is preserved, including routes such as:

```http
POST /api/v1/register
POST /api/v1/login
GET  /api/v1/me
GET  /api/v1/products
GET  /api/v1/product/:id
POST /api/v1/order/new
GET  /api/v1/orders/me
GET  /api/v1/admin/users
GET  /api/v1/admin/products
GET  /api/v1/admin/orders
```

## Progressive Risk

For each session, EvoGuard persists a `RiskProfile`. On a request it computes:

```text
Decayed Existing Risk
+ Rule Risk
+ Behavioral Risk
+ ML Risk
= New Risk (clamped to 0–100)
```

In this archive, `Behavioral Risk` and `ML Risk` remain `0` because those source modules were not included in the uploaded ZIP files. The integration points remain separated so those signals can be added later without moving final decision logic into the AI component.

Risk decays by `EVOGUARD_RISK_DECAY_PER_MINUTE` points per full minute between requests; the default is `1`.

## Authentication Security

The existing cookie-based JWT flow remains intact. Added protections include:

- Failed-login counter on the existing user model.
- 15-minute lockout after 5 failed password attempts.
- Brute-force detector synchronization by client IP.
- Login and registration rate limits.
- Authentication and authorization audit events in `SecurityLog`.
- A fix to the existing Mongoose password hook so saving lockout counters does not re-hash an unchanged password.

## Testing

Run the dependency-free security unit suite:

```powershell
npm run test:security
```

The suite checks normal traffic, SQL injection, sensitive-password redaction, legitimate admin access, anonymous admin enumeration, brute-force thresholds, progressive risk, risk decay, and all five decision tiers.

A full live integration test additionally requires MongoDB and the existing external service credentials used by EvoMart.

## Environment Variables

See `.env.example`. Only variables referenced by the integrated source are listed there. Real secrets are intentionally excluded from this archive.

## Cleanup

The final archive intentionally excludes:

- `node_modules/`
- frontend `build/`
- `.git/`
- real `.env` files
- caches and coverage output
- the standalone duplicate EvoGuard authentication application
- duplicate sample IDS servers

The useful security logic from those uploaded EvoGuard modules was integrated into the existing commerce application instead.

## Source Integration Notes

See `docs/INTEGRATION_REPORT.md` for source mapping, modifications, verified tests, unverified areas, and component status.
