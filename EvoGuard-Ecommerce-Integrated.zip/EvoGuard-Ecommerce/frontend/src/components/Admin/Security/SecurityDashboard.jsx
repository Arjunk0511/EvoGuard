import { useEffect, useState } from 'react';
import axios from 'axios';
import MetaData from '../../Layouts/MetaData';

const SecurityDashboard = () => {
  const [summary, setSummary] = useState(null);
  const [logs, setLogs] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    let mounted = true;

    const loadSecurityData = async () => {
      try {
        const [summaryResponse, logsResponse] = await Promise.all([
          axios.get('/api/v1/admin/security/summary'),
          axios.get('/api/v1/admin/security/logs?limit=50'),
        ]);

        if (!mounted) return;
        setSummary(summaryResponse.data.summary);
        setLogs(logsResponse.data.logs || []);
      } catch (requestError) {
        if (!mounted) return;
        setError(requestError.response?.data?.message || 'Unable to load EvoGuard security data.');
      }
    };

    loadSecurityData();
    return () => {
      mounted = false;
    };
  }, []);

  const cards = summary
    ? [
        ['Total Requests', summary.totalRequests],
        ['Blocked', summary.blocked],
        ['Monitored', summary.monitored],
        ['Rate Limited', summary.rateLimited],
        ['Redirected', summary.redirected],
        ['Honeypot', summary.honeypot],
        ['High-Risk Sessions', summary.highRiskSessions],
      ]
    : [];

  return (
    <>
      <MetaData title="Security Dashboard | EvoMart" />
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-2xl font-semibold text-gray-800">EvoGuard Security</h1>
          <p className="text-sm text-gray-500">Progressive risk, security decisions, and recent events.</p>
        </div>

        {error && <div className="rounded bg-red-100 text-red-700 p-3">{error}</div>}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {cards.map(([label, value]) => (
            <div key={label} className="bg-white rounded-lg shadow p-4">
              <div className="text-sm text-gray-500">{label}</div>
              <div className="text-2xl font-semibold text-gray-800">{value}</div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow overflow-x-auto">
          <div className="p-4 border-b font-semibold text-gray-800">Recent Security Events</div>
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50 text-left text-gray-600">
              <tr>
                <th className="p-3">Time</th>
                <th className="p-3">Event</th>
                <th className="p-3">Endpoint</th>
                <th className="p-3">Risk</th>
                <th className="p-3">Decision</th>
                <th className="p-3">Signals</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => (
                <tr key={log._id} className="border-t">
                  <td className="p-3 whitespace-nowrap">{new Date(log.createdAt).toLocaleString()}</td>
                  <td className="p-3">{log.eventType}</td>
                  <td className="p-3 max-w-xs truncate">{log.endpoint || '-'}</td>
                  <td className="p-3">{log.riskScore ?? 0}</td>
                  <td className="p-3">{log.decision || '-'}</td>
                  <td className="p-3">{(log.signals || []).join(', ') || '-'}</td>
                </tr>
              ))}
              {!logs.length && !error && (
                <tr>
                  <td className="p-4 text-gray-500" colSpan="6">No security events have been recorded yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default SecurityDashboard;
