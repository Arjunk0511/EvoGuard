import axios from 'axios';

const SESSION_KEY = 'evogateSessionId';

const randomSessionId = () => {
  if (window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }

  return `eg-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
};

export const initializeEvoGateSession = () => {
  let sessionId = sessionStorage.getItem(SESSION_KEY);

  if (!sessionId) {
    sessionId = randomSessionId();
    sessionStorage.setItem(SESSION_KEY, sessionId);
  }

  axios.defaults.headers.common['X-Session-ID'] = sessionId;
  return sessionId;
};
