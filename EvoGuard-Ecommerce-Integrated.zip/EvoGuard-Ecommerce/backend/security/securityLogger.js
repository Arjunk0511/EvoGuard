const SecurityLog = require("../models/SecurityLog");

function getIp(req) {
  const forwarded = req?.headers?.["x-forwarded-for"];
  if (forwarded) return forwarded.split(",")[0].trim();
  return req?.ip || req?.socket?.remoteAddress || null;
}

function requestMetadata(req) {
  const userAgent = req?.headers?.["user-agent"] || null;
  const requestSize = Number(req?.headers?.["content-length"]) || 0;

  return {
    userAgent,
    contentType: req?.headers?.["content-type"] || null,
    referer: req?.headers?.referer || req?.headers?.referrer || null,
    requestSize,
    deviceType: userAgent && /mobile|android|iphone|ipad/i.test(userAgent) ? "mobile" : "desktop",
  };
}

async function logSecurityEvent({
  eventType,
  req = null,
  requestId = null,
  sessionId = null,
  userId = null,
  riskScore = 0,
  riskLevel = null,
  signals = [],
  decision = null,
  reasons = [],
  details = null,
}) {
  try {
    await SecurityLog.create({
      eventType,
      requestId,
      sessionId,
      userId,
      ipAddress: getIp(req),
      endpoint: req?.originalUrl || req?.url || null,
      method: req?.method || null,
      riskScore,
      riskLevel,
      signals,
      decision,
      reasons,
      details,
      metadata: requestMetadata(req),
    });
  } catch (error) {
    // Security logging is best-effort and must not break application functionality.
    console.error("EvoGuard security logging error:", error.message);
  }
}

module.exports = { logSecurityEvent, getIp, requestMetadata };
