const {
  sqlInjectionDetector,
  xssDetector,
  pathTraversalDetector,
  suspiciousUrlDetector,
  botDetector,
  bruteForceDetector,
  requestRateDetector,
  adminEnumerationDetector,
} = require("./detectors");

const { RISK_THRESHOLDS } = require("./constants");

function getIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) return forwarded.split(",")[0].trim();
  return req.ip || req.socket?.remoteAddress || "unknown";
}

function analyzeRequest(req) {
  const ip = getIp(req);
  requestRateDetector.recordRequest(ip);

  const detectorResults = [
    sqlInjectionDetector(req),
    xssDetector(req),
    pathTraversalDetector(req),
    suspiciousUrlDetector(req),
    botDetector(req),
    adminEnumerationDetector(req),
    bruteForceDetector.checkBruteForce(ip),
    requestRateDetector.checkRequestRate(ip),
  ];

  let totalRisk = 0;
  const attackTypes = new Set();
  const reasons = [];

  for (const result of detectorResults) {
    if (result.detected) {
      totalRisk += Number(result.score) || 0;
      if (result.attackType) attackTypes.add(result.attackType);
      if (result.reason) reasons.push(result.reason);
    }
  }

  return {
    detected: attackTypes.size > 0,
    timestamp: new Date().toISOString(),
    ruleRisk: Math.min(Math.max(totalRisk, 0), RISK_THRESHOLDS.MAX_SCORE),
    attackTypes: [...attackTypes],
    reasons,
    detectorDetails: detectorResults,
  };
}

module.exports = analyzeRequest;
