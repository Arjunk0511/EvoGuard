module.exports = {
  MAX_FAILED_LOGIN_ATTEMPTS: 5,
  ACCOUNT_LOCK_DURATION_MS: 15 * 60 * 1000,
  LOGIN_RATE_LIMIT: { windowMs: 15 * 60 * 1000, limit: 5 },
  REGISTER_RATE_LIMIT: { windowMs: 15 * 60 * 1000, limit: 3 },
  ADMIN_RATE_LIMIT: { windowMs: 15 * 60 * 1000, limit: 30 },
};
