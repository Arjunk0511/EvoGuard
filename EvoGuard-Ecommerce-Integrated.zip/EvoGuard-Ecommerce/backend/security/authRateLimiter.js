const { LOGIN_RATE_LIMIT, REGISTER_RATE_LIMIT, ADMIN_RATE_LIMIT } = require("./authPolicy");

const buckets = new Map();

function clientKey(req, bucketName) {
  const forwarded = req.headers["x-forwarded-for"];
  const ip = forwarded ? forwarded.split(",")[0].trim() : req.ip || req.socket?.remoteAddress || "unknown";
  return `${bucketName}:${ip}`;
}

function createLimiter(name, config) {
  return (req, res, next) => {
    const key = clientKey(req, name);
    const now = Date.now();
    const current = buckets.get(key);

    if (!current || now - current.startedAt >= config.windowMs) {
      buckets.set(key, { startedAt: now, count: 1 });
      return next();
    }

    current.count += 1;

    if (current.count > config.limit) {
      const retryAfter = Math.max(Math.ceil((config.windowMs - (now - current.startedAt)) / 1000), 1);
      res.set("Retry-After", String(retryAfter));
      return res.status(429).json({
        success: false,
        message: "Too many requests. Please try again later.",
      });
    }

    next();
  };
}

module.exports = {
  loginRateLimiter: createLimiter("login", LOGIN_RATE_LIMIT),
  registerRateLimiter: createLimiter("register", REGISTER_RATE_LIMIT),
  adminRateLimiter: createLimiter("admin", ADMIN_RATE_LIMIT),
};
