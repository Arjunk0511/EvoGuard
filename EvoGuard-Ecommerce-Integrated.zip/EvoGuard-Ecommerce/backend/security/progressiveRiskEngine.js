const MAX_RISK = 100;
const DEFAULT_DECAY_PER_MINUTE = 1;

function clamp(value) {
  return Math.min(Math.max(Number(value) || 0, 0), MAX_RISK);
}

function calculateProgressiveRisk({
  existingRisk = 0,
  ruleRisk = 0,
  behavioralRisk = 0,
  mlRisk = 0,
  lastUpdated = null,
  now = new Date(),
}) {
  const decayPerMinute = Math.max(
    Number(process.env.EVOGUARD_RISK_DECAY_PER_MINUTE) || DEFAULT_DECAY_PER_MINUTE,
    0,
  );

  const elapsedMs = lastUpdated ? Math.max(now.getTime() - new Date(lastUpdated).getTime(), 0) : 0;
  const elapsedMinutes = Math.floor(elapsedMs / 60000);
  const timeDecay = elapsedMinutes * decayPerMinute;
  const decayedExistingRisk = clamp(existingRisk - timeDecay);

  const totalRisk = clamp(
    decayedExistingRisk + Number(ruleRisk || 0) + Number(behavioralRisk || 0) + Number(mlRisk || 0),
  );

  return {
    existingRisk: clamp(existingRisk),
    decayedExistingRisk,
    ruleRisk: clamp(ruleRisk),
    behavioralRisk: clamp(behavioralRisk),
    mlRisk: clamp(mlRisk),
    timeDecay,
    totalRisk,
  };
}

module.exports = calculateProgressiveRisk;
