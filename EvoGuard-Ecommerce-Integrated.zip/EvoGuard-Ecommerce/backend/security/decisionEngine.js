const { RISK_THRESHOLDS: DECISION_THRESHOLDS } = require("./constants");

function deceptionTarget(signals = []) {
  if (signals.includes("BRUTE_FORCE")) return "/api/v1/deception/login";
  if (signals.includes("ADMIN_ENUMERATION")) return "/api/v1/deception/admin";
  if (signals.includes("SQL_INJECTION")) return "/api/v1/deception/database";
  if (signals.includes("SUSPICIOUS_USER_AGENT") || signals.includes("HIGH_REQUEST_RATE")) {
    return "/api/v1/deception/catalog";
  }
  return "/api/v1/deception/catalog";
}

function makeDecision({ riskScore, signals = [] }) {
  const risk = Math.min(Math.max(Number(riskScore) || 0, 0), DECISION_THRESHOLDS.MAX_SCORE);

  if (risk >= DECISION_THRESHOLDS.BLOCK) {
    return { action: "BLOCK", riskLevel: "CRITICAL", reason: "Risk score reached the blocking threshold." };
  }

  if (risk >= DECISION_THRESHOLDS.REDIRECT) {
    return {
      action: "REDIRECT",
      riskLevel: "HIGH",
      reason: "High-risk request is routed to a deception endpoint.",
      redirectTo: deceptionTarget(signals),
    };
  }

  if (risk >= DECISION_THRESHOLDS.RATE_LIMIT) {
    return { action: "RATE_LIMIT", riskLevel: "ELEVATED", reason: "Risk score requires temporary rate limiting." };
  }

  if (risk >= DECISION_THRESHOLDS.MONITOR) {
    return { action: "MONITOR", riskLevel: "MEDIUM", reason: "Request is allowed with enhanced monitoring." };
  }

  return { action: "ALLOW", riskLevel: "LOW", reason: "Risk score is below intervention thresholds." };
}

module.exports = { makeDecision, DECISION_THRESHOLDS };
