const { RISK_SCORES } = require("../constants");

const ADMIN_PATTERNS = [
  "/admin",
  "/wp-admin",
  "/administrator",
  "/phpmyadmin",
];

function adminEnumerationDetector(req) {
  const path = (req.originalUrl || req.url || "").toLowerCase();

  // Legitimate authenticated EvoMart administrators must not be classified as probes.
  if (req.evoGateIdentity?.role === "admin") {
    return {
      detector: "AdminEnumerationDetector",
      detected: false,
      attackType: null,
      severity: null,
      score: 0,
      reason: null,
    };
  }

  const isAdminProbe = ADMIN_PATTERNS.some((pattern) => path.includes(pattern));

  if (!isAdminProbe) {
    return {
      detector: "AdminEnumerationDetector",
      detected: false,
      attackType: null,
      severity: null,
      score: 0,
      reason: null,
    };
  }

  return {
    detector: "AdminEnumerationDetector",
    detected: true,
    attackType: "ADMIN_ENUMERATION",
    severity: "HIGH",
    score: RISK_SCORES.ADMIN_ENUMERATION,
    reason: `Unauthenticated admin endpoint access detected: ${path}`,
  };
}

module.exports = adminEnumerationDetector;
