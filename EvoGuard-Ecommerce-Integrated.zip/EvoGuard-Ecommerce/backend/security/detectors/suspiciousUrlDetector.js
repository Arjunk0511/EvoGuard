const { RISK_SCORES } = require("../constants");

// Legitimate EvoMart admin routes are handled by AdminEnumerationDetector, which can
// distinguish authenticated admins from anonymous probes. Keeping "admin" here would
// double-count and block the application's real admin dashboard.
const SUSPICIOUS_PATHS = [
  ".env",
  ".git",
  "wp-admin",
  "wp-login",
  "phpmyadmin",
  "server-status",
  "backup",
];

function suspiciousUrlDetector(req) {
  const url = (req.originalUrl || req.url || req.path || "").toLowerCase();

  for (const suspiciousPath of SUSPICIOUS_PATHS) {
    if (url.includes(suspiciousPath)) {
      return {
        detector: "SuspiciousUrlDetector",
        detected: true,
        attackType: "SUSPICIOUS_URL",
        severity: "MEDIUM",
        score: RISK_SCORES.SUSPICIOUS_URL,
        reason: `Suspicious URL access detected: ${suspiciousPath}`,
      };
    }
  }

  return {
    detector: "SuspiciousUrlDetector",
    detected: false,
    attackType: null,
    severity: null,
    score: 0,
    reason: null,
  };
}

module.exports = suspiciousUrlDetector;
