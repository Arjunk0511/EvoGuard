const SENSITIVE_KEYS = new Set([
  "password",
  "confirmpassword",
  "oldpassword",
  "newpassword",
  "token",
  "accesstoken",
  "refreshtoken",
  "authorization",
  "cardnumber",
  "cvv",
]);

function sanitize(value) {
  if (Array.isArray(value)) {
    return value.map(sanitize);
  }

  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([key, fieldValue]) => [
        key,
        SENSITIVE_KEYS.has(key.toLowerCase()) ? "[REDACTED]" : sanitize(fieldValue),
      ]),
    );
  }

  return value;
}

function safeStringify(value) {
  if (value === undefined || value === null) return "";
  if (typeof value === "string") return value;

  try {
    return JSON.stringify(value);
  } catch (error) {
    return String(value);
  }
}

function extractRequestData(req) {
  return [
    safeStringify(sanitize(req.body || {})),
    safeStringify(sanitize(req.query || {})),
    safeStringify(sanitize(req.params || {})),
    safeStringify(req.originalUrl || req.url || ""),
    safeStringify(req.path || ""),
  ];
}

module.exports = extractRequestData;
