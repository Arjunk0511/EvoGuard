const jwt = require("jsonwebtoken");
const { v4: uuidv4 } = require("uuid");
const User = require("../models/userModel");

function cleanSessionId(value) {
  if (!value || typeof value !== "string") return null;
  const cleaned = value.trim().replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 128);
  return cleaned || null;
}

async function resolveAuthenticatedIdentity(req) {
  const token = req.cookies?.token;
  if (!token || !process.env.JWT_SECRET) return null;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select("_id role");
    if (!user) return null;

    return {
      userId: user._id,
      role: user.role,
    };
  } catch (error) {
    return null;
  }
}

async function resolveRequestContext(req, res) {
  const requestId = uuidv4();
  const identity = await resolveAuthenticatedIdentity(req);
  req.evoGateIdentity = identity;

  const headerSession = cleanSessionId(req.get("X-Session-ID"));
  const cookieSession = cleanSessionId(req.cookies?.evogate_session);

  let sessionId = headerSession;

  if (!sessionId && identity?.userId) {
    sessionId = `user-${identity.userId}`;
  }

  if (!sessionId) {
    sessionId = cookieSession || uuidv4();
  }

  if (!cookieSession && !headerSession && !identity?.userId) {
    res.cookie("evogate_session", sessionId, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000,
    });
  }

  res.set("X-Request-ID", requestId);
  res.set("X-EvoGate-Session-ID", sessionId);

  return { requestId, sessionId, identity };
}

module.exports = resolveRequestContext;
