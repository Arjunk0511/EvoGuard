const mongoose = require("mongoose");

const riskProfileSchema = new mongoose.Schema(
  {
    sessionId: { type: String, required: true, unique: true, index: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null, index: true },
    ipAddress: { type: String, default: null },
    currentRisk: { type: Number, default: 0, min: 0, max: 100 },
    lastSignals: { type: [String], default: [] },
    lastDecision: { type: String, default: "ALLOW" },
    lastRequestAt: { type: Date, default: Date.now },
  },
  { timestamps: true },
);

module.exports = mongoose.model("RiskProfile", riskProfileSchema);
