const mongoose = require("mongoose");

const securityLogSchema = new mongoose.Schema(
  {
    eventType: { type: String, required: true, index: true },
    requestId: { type: String, default: null, index: true },
    sessionId: { type: String, default: null, index: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null, index: true },
    ipAddress: { type: String, default: null },
    endpoint: { type: String, default: null },
    method: { type: String, default: null },
    riskScore: { type: Number, default: 0, min: 0, max: 100 },
    riskLevel: { type: String, default: null },
    signals: { type: [String], default: [] },
    decision: { type: String, default: null, index: true },
    reasons: { type: [String], default: [] },
    details: { type: String, default: null },
    metadata: {
      userAgent: { type: String, default: null },
      contentType: { type: String, default: null },
      referer: { type: String, default: null },
      requestSize: { type: Number, default: 0 },
      deviceType: { type: String, default: "unknown" },
    },
  },
  { timestamps: true },
);

securityLogSchema.index({ createdAt: -1 });

module.exports = mongoose.model("SecurityLog", securityLogSchema);
