const express = require("express");
const SecurityLog = require("../models/SecurityLog");
const RiskProfile = require("../models/RiskProfile");
const { isAuthenticatedUser, authorizeRoles } = require("../middlewares/auth");
const { adminRateLimiter } = require("../security/authRateLimiter");

const router = express.Router();

router.get(
  "/admin/security/logs",
  isAuthenticatedUser,
  authorizeRoles("admin"),
  adminRateLimiter,
  async (req, res, next) => {
    try {
      const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 200);
      const logs = await SecurityLog.find().sort({ createdAt: -1 }).limit(limit).lean();
      res.status(200).json({ success: true, count: logs.length, logs });
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/admin/security/summary",
  isAuthenticatedUser,
  authorizeRoles("admin"),
  adminRateLimiter,
  async (req, res, next) => {
    try {
      const [totalRequests, blocked, monitored, rateLimited, redirected, honeypot, highRiskSessions] = await Promise.all([
        SecurityLog.countDocuments({ eventType: "REQUEST_ANALYZED" }),
        SecurityLog.countDocuments({ eventType: "REQUEST_ANALYZED", decision: "BLOCK" }),
        SecurityLog.countDocuments({ eventType: "REQUEST_ANALYZED", decision: "MONITOR" }),
        SecurityLog.countDocuments({ eventType: "REQUEST_ANALYZED", decision: "RATE_LIMIT" }),
        SecurityLog.countDocuments({ eventType: "REQUEST_ANALYZED", decision: "REDIRECT" }),
        SecurityLog.countDocuments({ eventType: "HONEYPOT_ENGAGED" }),
        RiskProfile.countDocuments({ currentRisk: { $gte: 70 } }),
      ]);

      res.status(200).json({
        success: true,
        summary: { totalRequests, blocked, monitored, rateLimited, redirected, honeypot, highRiskSessions },
      });
    } catch (error) {
      next(error);
    }
  },
);

module.exports = router;
