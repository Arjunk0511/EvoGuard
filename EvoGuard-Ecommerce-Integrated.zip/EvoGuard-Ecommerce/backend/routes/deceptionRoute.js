const express = require("express");
const { logSecurityEvent } = require("../security/securityLogger");

const router = express.Router();

async function logHoneypot(req, target) {
  await logSecurityEvent({
    eventType: "HONEYPOT_ENGAGED",
    req,
    requestId: req.securityContext?.requestId || null,
    sessionId: req.securityContext?.sessionId || null,
    decision: "DECEPTION",
    details: `Deception target engaged: ${target}`,
  });
}

router.all("/login", async (req, res) => {
  await logHoneypot(req, "login");
  res.status(200).json({ success: true, message: "Authentication service accepted the request." });
});

router.all("/admin", async (req, res) => {
  await logHoneypot(req, "admin");
  res.status(200).json({ success: true, dashboard: { users: 0, orders: 0, alerts: [] } });
});

router.all("/database", async (req, res) => {
  await logHoneypot(req, "database");
  res.status(200).json({ success: true, records: [], message: "Query completed." });
});

router.all("/catalog", async (req, res) => {
  await logHoneypot(req, "catalog");
  res.status(200).json({ success: true, products: [], message: "Catalogue loaded." });
});

module.exports = router;
