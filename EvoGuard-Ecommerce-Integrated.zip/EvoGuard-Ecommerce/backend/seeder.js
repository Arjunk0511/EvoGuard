const mongoose = require("mongoose");
const dotenv = require("dotenv");
const Product = require("./models/productModel"); // Adjust path if needed

dotenv.config();

const products = [
  {
    name: "Puma Running Shoes",
    description:
      "High-performance running shoes with breathable mesh and cushioned sole.",
    highlights: [
      "Breathable Mesh",
      "Cushioned Midsole",
      "Durable Rubber Outsole",
    ],
    specifications: [
      {
        title: "Closure",
        description: "Lace-Up",
      },
      {
        title: "Type",
        description: "Running",
      },
    ],
    price: 3499,
    cuttedPrice: 4999,
    images: [
      {
        // This public_id must be unique to this image
        public_id: "products/puma_white_sneakers_1",
        url: "https://images.clothes.com/products/shoes/puma/classic_white_sneaker_angle.jpg",
      },
    ],
    brand: {
      name: "Puma",
      logo: {
        public_id: "brands/puma_logo",
        url: "https://via.placeholder.com/100",
      },
    },
    category: "Footwear",
    stock: 50,
    user: "69de0ec6189dc2b3340bb99d", // Get this from MongoDB Compass
  },
];

const seedProducts = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Database Connected for seeding...");

    await Product.deleteMany();
    console.log("Old products cleared.");

    await Product.insertMany(products);
    console.log("Products seeded successfully!");

    process.exit();
  } catch (error) {
    console.error("Error seeding data:", error.message);
    process.exit(1);
  }
};

seedProducts();
