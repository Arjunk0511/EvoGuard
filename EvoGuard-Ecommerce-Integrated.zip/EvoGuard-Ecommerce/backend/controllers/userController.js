const User = require('../models/userModel');
const asyncErrorHandler = require('../middlewares/asyncErrorHandler');
const sendToken = require('../utils/sendToken');
const ErrorHandler = require('../utils/errorHandler');
const sendEmail = require('../utils/sendEmail');
const crypto = require('crypto');
const cloudinary = require('cloudinary');
const { logSecurityEvent, getIp } = require('../security/securityLogger');
const { bruteForceDetector } = require('../security/detectors');
const {
    MAX_FAILED_LOGIN_ATTEMPTS,
    ACCOUNT_LOCK_DURATION_MS,
} = require('../security/authPolicy');

// Register User
exports.registerUser = asyncErrorHandler(async (req, res, next) => {
    const { name, email, gender, password } = req.body;
    const normalizedEmail = String(email || '').toLowerCase().trim();

    const existingUser = await User.findOne({ email: normalizedEmail });
    if (existingUser) {
        await logSecurityEvent({
            eventType: 'REGISTER_DUPLICATE',
            req,
            userId: existingUser._id,
            details: 'Registration attempted with an existing email',
        });
        return next(new ErrorHandler('An account with this email already exists', 409));
    }

    const myCloud = await cloudinary.v2.uploader.upload(req.body.avatar, {
        folder: 'avatars',
        width: 150,
        crop: 'scale',
    });

    const user = await User.create({
        name,
        email: normalizedEmail,
        gender,
        password,
        avatar: {
            public_id: myCloud.public_id,
            url: myCloud.secure_url,
        },
    });

    await logSecurityEvent({
        eventType: 'REGISTER_SUCCESS',
        req,
        userId: user._id,
        details: 'User registration completed',
    });

    sendToken(user, 201, res);
});

// Login User
exports.loginUser = asyncErrorHandler(async (req, res, next) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return next(new ErrorHandler('Please Enter Email And Password', 400));
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    const user = await User.findOne({ email: normalizedEmail }).select('+password');

    if (!user) {
        await logSecurityEvent({
            eventType: 'LOGIN_FAILED',
            req,
            details: 'Login failed for an unknown account',
        });
        return next(new ErrorHandler('Invalid Email or Password', 401));
    }

    if (user.accountLockedUntil && user.accountLockedUntil > new Date()) {
        await logSecurityEvent({
            eventType: 'ACCOUNT_LOCKED',
            req,
            userId: user._id,
            details: 'Login attempted while account lockout is active',
        });
        return next(new ErrorHandler('Account temporarily locked. Please try again later.', 423));
    }

    if (user.accountLockedUntil && user.accountLockedUntil <= new Date()) {
        user.accountLockedUntil = null;
        user.failedLoginAttempts = 0;
        await user.save();
    }

    const isPasswordMatched = await user.comparePassword(password);
    const ip = getIp(req) || 'unknown';

    if (!isPasswordMatched) {
        user.failedLoginAttempts += 1;
        bruteForceDetector.recordFailedAttempt(ip);

        await logSecurityEvent({
            eventType: 'LOGIN_FAILED',
            req,
            userId: user._id,
            details: `Failed login attempt ${user.failedLoginAttempts}`,
        });

        if (user.failedLoginAttempts >= MAX_FAILED_LOGIN_ATTEMPTS) {
            user.accountLockedUntil = new Date(Date.now() + ACCOUNT_LOCK_DURATION_MS);
            await user.save();

            await logSecurityEvent({
                eventType: 'ACCOUNT_LOCKED',
                req,
                userId: user._id,
                details: `Account locked after ${user.failedLoginAttempts} failed login attempts`,
            });

            return next(new ErrorHandler('Account temporarily locked. Please try again later.', 423));
        }

        await user.save();
        return next(new ErrorHandler('Invalid Email or Password', 401));
    }

    user.failedLoginAttempts = 0;
    user.accountLockedUntil = null;
    await user.save();
    bruteForceDetector.clearAttempts(ip);

    await logSecurityEvent({
        eventType: 'LOGIN_SUCCESS',
        req,
        userId: user._id,
        details: 'User login completed',
    });

    sendToken(user, 201, res);
});

// Logout User
exports.logoutUser = asyncErrorHandler(async (req, res, next) => {
    res.cookie("token", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
    });

    res.status(200).json({
        success: true,
        message: "Logged Out",
    });
});

// Get User Details
exports.getUserDetails = asyncErrorHandler(async (req, res, next) => {
    
    const user = await User.findById(req.user.id);

    res.status(200).json({
        success: true,
        user,
    });
});

// Forgot Password
exports.forgotPassword = asyncErrorHandler(async (req, res, next) => {
    
    const user = await User.findOne({email: req.body.email});

    if(!user) {
        return next(new ErrorHandler("User Not Found", 404));
    }

    const resetToken = await user.getResetPasswordToken();

    await user.save({ validateBeforeSave: false });

    // const resetPasswordUrl = `${req.protocol}://${req.get("host")}/password/reset/${resetToken}`;
    const resetPasswordUrl = `https://${req.get("host")}/password/reset/${resetToken}`;

    // const message = `Your password reset token is : \n\n ${resetPasswordUrl}`;

    try {
        await sendEmail({
            email: user.email,
            templateId: process.env.SENDGRID_RESET_TEMPLATEID,
            data: {
                reset_url: resetPasswordUrl
            }
        });

        res.status(200).json({
            success: true,
            message: `Email sent to ${user.email} successfully`,
        });

    } catch (error) {
        user.resetPasswordToken = undefined;
        user.resetPasswordExpire = undefined;

        await user.save({ validateBeforeSave: false });
        return next(new ErrorHandler(error.message, 500))
    }
});

// Reset Password
exports.resetPassword = asyncErrorHandler(async (req, res, next) => {

    // create hash token
    const resetPasswordToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

    const user = await User.findOne({ 
        resetPasswordToken,
        resetPasswordExpire: { $gt: Date.now() }
    });

    if(!user) {
        return next(new ErrorHandler("Invalid reset password token", 404));
    }

    user.password = req.body.password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;

    await user.save();
    sendToken(user, 200, res);
});

// Update Password
exports.updatePassword = asyncErrorHandler(async (req, res, next) => {

    const user = await User.findById(req.user.id).select("+password");

    const isPasswordMatched = await user.comparePassword(req.body.oldPassword);

    if(!isPasswordMatched) {
        return next(new ErrorHandler("Old Password is Invalid", 400));
    }

    user.password = req.body.newPassword;
    await user.save();
    sendToken(user, 201, res);
});

// Update User Profile
exports.updateProfile = asyncErrorHandler(async (req, res, next) => {

    const newUserData = {
        name: req.body.name,
        email: req.body.email,
    }

    if(req.body.avatar !== "") {
        const user = await User.findById(req.user.id);

        const imageId = user.avatar.public_id;

        await cloudinary.v2.uploader.destroy(imageId);

        const myCloud = await cloudinary.v2.uploader.upload(req.body.avatar, {
            folder: "avatars",
            width: 150,
            crop: "scale",
        });

        newUserData.avatar = {
            public_id: myCloud.public_id,
            url: myCloud.secure_url,
        }
    }

    await User.findByIdAndUpdate(req.user.id, newUserData, {
        new: true,
        runValidators: true,
        useFindAndModify: true,
    });

    res.status(200).json({
        success: true,
    });
});

// ADMIN DASHBOARD

// Get All Users --ADMIN
exports.getAllUsers = asyncErrorHandler(async (req, res, next) => {

    const users = await User.find();

    res.status(200).json({
        success: true,
        users,
    });
});

// Get Single User Details --ADMIN
exports.getSingleUser = asyncErrorHandler(async (req, res, next) => {

    const user = await User.findById(req.params.id);

    if(!user) {
        return next(new ErrorHandler(`User doesn't exist with id: ${req.params.id}`, 404));
    }

    res.status(200).json({
        success: true,
        user,
    });
});

// Update User Role --ADMIN
exports.updateUserRole = asyncErrorHandler(async (req, res, next) => {

    const newUserData = {
        name: req.body.name,
        email: req.body.email,
        gender: req.body.gender,
        role: req.body.role,
    }

    await User.findByIdAndUpdate(req.params.id, newUserData, {
        new: true,
        runValidators: true,
        useFindAndModify: false,
    });

    res.status(200).json({
        success: true,
    });
});

// Delete Role --ADMIN
exports.deleteUser = asyncErrorHandler(async (req, res, next) => {

    const user = await User.findById(req.params.id);

    if(!user) {
        return next(new ErrorHandler(`User doesn't exist with id: ${req.params.id}`, 404));
    }

    await user.remove();

    res.status(200).json({
        success: true
    });
});