const analyzeRequest = require("../security/riskEngine");
const calculateProgressiveRisk = require("../security/progressiveRiskEngine");
const { makeDecision } = require("../security/decisionEngine");
const resolveRequestContext = require("../security/sessionResolver");
const { logSecurityEvent, getIp } = require("../security/securityLogger");
const RiskProfile = require("../models/RiskProfile");

const DECEPTION_PREFIX = "/api/v1/deception";

async function evoGateMiddleware(req, res, next) {
  try {
    const { requestId, sessionId, identity } = await resolveRequestContext(req, res);

    // Deception endpoints are intentionally outside normal risk enforcement to avoid redirect loops.
    if ((req.originalUrl || "").startsWith(DECEPTION_PREFIX)) {
      req.securityContext = { requestId, sessionId, bypass: "DECEPTION_ENDPOINT" };
      return next();
    }

    const ruleAnalysis = analyzeRequest(req);
    const profile = await RiskProfile.findOneAndUpdate(
      { sessionId },
      {
        $setOnInsert: {
          sessionId,
          userId: identity?.userId || null,
          ipAddress: getIp(req),
          currentRisk: 0,
          lastRequestAt: new Date(),
        },
      },
      { upsert: true, new: true, setDefaultsOnInsert: true },
    );

    const progressiveRisk = calculateProgressiveRisk({
      existingRisk: profile.currentRisk,
      ruleRisk: ruleAnalysis.ruleRisk,
      behavioralRisk: 0,
      mlRisk: 0,
      lastUpdated: profile.lastRequestAt,
    });

    const decision = makeDecision({
      riskScore: progressiveRisk.totalRisk,
      signals: ruleAnalysis.attackTypes,
      endpoint: req.originalUrl,
    });

    profile.userId = identity?.userId || profile.userId || null;
    profile.ipAddress = getIp(req);
    profile.currentRisk = progressiveRisk.totalRisk;
    profile.lastSignals = ruleAnalysis.attackTypes;
    profile.lastDecision = decision.action;
    profile.lastRequestAt = new Date();
    await profile.save();

    req.securityContext = {
      requestId,
      sessionId,
      ruleAnalysis,
      progressiveRisk,
      decision,
    };

    await logSecurityEvent({
      eventType: "REQUEST_ANALYZED",
      req,
      requestId,
      sessionId,
      userId: identity?.userId || null,
      riskScore: progressiveRisk.totalRisk,
      riskLevel: decision.riskLevel,
      signals: ruleAnalysis.attackTypes,
      decision: decision.action,
      reasons: [...ruleAnalysis.reasons, decision.reason],
    });

    if (decision.action === "BLOCK") {
      return res.status(403).json({
        success: false,
        error: {
          code: "REQUEST_BLOCKED",
          message: "Request blocked by EvoGuard security policy.",
          requestId,
        },
      });
    }

    if (decision.action === "RATE_LIMIT") {
      res.set("Retry-After", "60");
      return res.status(429).json({
        success: false,
        error: {
          code: "REQUEST_RATE_LIMITED",
          message: "Request temporarily rate limited by EvoGuard security policy.",
          requestId,
        },
      });
    }

    if (decision.action === "REDIRECT") {
      return res.redirect(307, decision.redirectTo);
    }

    return next();
  } catch (error) {
    // Preserve the e-commerce application if the security layer itself fails.
    console.error("EvoGuard middleware error:", error.message);
    return next();
  }
}

module.exports = evoGateMiddleware;
