const jwt = require('jsonwebtoken');
const User = require('../models/userModel');
const ErrorHandler = require('../utils/errorHandler');
const asyncErrorHandler = require('./asyncErrorHandler');
const { logSecurityEvent } = require('../security/securityLogger');

exports.isAuthenticatedUser = asyncErrorHandler(async (req, res, next) => {
    const { token } = req.cookies;

    if (!token) {
        await logSecurityEvent({
            eventType: 'AUTHENTICATION_FAILED',
            req,
            requestId: req.securityContext?.requestId || null,
            sessionId: req.securityContext?.sessionId || null,
            details: 'Protected route accessed without an authentication cookie',
        });
        return next(new ErrorHandler('Please Login to Access', 401));
    }

    try {
        const decodedData = jwt.verify(token, process.env.JWT_SECRET);
        const user = await User.findById(decodedData.id);

        if (!user) {
            await logSecurityEvent({
                eventType: 'AUTHENTICATION_FAILED',
                req,
                details: 'JWT referenced a user that no longer exists',
            });
            return next(new ErrorHandler('Please Login to Access', 401));
        }

        req.user = user;
        next();
    } catch (error) {
        await logSecurityEvent({
            eventType: 'AUTHENTICATION_FAILED',
            req,
            details: 'Invalid or expired JWT cookie',
        });
        return next(new ErrorHandler('Invalid or expired authentication token', 401));
    }
});

exports.authorizeRoles = (...roles) => {
    return async (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            await logSecurityEvent({
                eventType: 'AUTHORIZATION_FAILED',
                req,
                userId: req.user._id,
                details: `Role ${req.user.role} is not authorized. Required role: ${roles.join(', ')}`,
            });
            return next(new ErrorHandler(`Role: ${req.user.role} is not allowed`, 403));
        }
        next();
    };
};
