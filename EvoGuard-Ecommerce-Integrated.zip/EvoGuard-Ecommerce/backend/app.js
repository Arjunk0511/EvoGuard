const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const fileUpload = require('express-fileupload');
const errorMiddleware = require('./middlewares/error');
const securityHeaders = require('./middlewares/securityHeaders');
const evoGateMiddleware = require('./middlewares/evoGateMiddleware');

const app = express();

if (process.env.NODE_ENV !== 'production') {
    require('dotenv').config();
}

app.use(securityHeaders);
app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: true, limit: '2mb' }));
app.use(fileUpload());

const user = require('./routes/userRoute');
const product = require('./routes/productRoute');
const order = require('./routes/orderRoute');
const payment = require('./routes/paymentRoute');
const security = require('./routes/securityRoute');
const deception = require('./routes/deceptionRoute');

app.get('/api/v1/security/health', (req, res) => {
    res.status(200).json({ success: true, message: 'EvoGuard security layer is available.' });
});

// EvoGuard runs before protected e-commerce APIs. Deception routes are bypassed inside the middleware.
app.use('/api/v1', evoGateMiddleware);

app.use('/api/v1/deception', deception);
app.use('/api/v1', security);
app.use('/api/v1', user);
app.use('/api/v1', product);
app.use('/api/v1', order);
app.use('/api/v1', payment);

app.use(errorMiddleware);

module.exports = app;
