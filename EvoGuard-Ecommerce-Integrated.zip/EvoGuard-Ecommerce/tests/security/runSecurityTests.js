const assert = require('assert');
const analyzeRequest = require('../../backend/security/riskEngine');
const calculateProgressiveRisk = require('../../backend/security/progressiveRiskEngine');
const { makeDecision } = require('../../backend/security/decisionEngine');
const { bruteForceDetector } = require('../../backend/security/detectors');

function request(overrides = {}) {
  return {
    body: {},
    query: {},
    params: {},
    originalUrl: '/api/v1/products',
    path: '/products',
    headers: { 'user-agent': 'Mozilla/5.0', ...overrides.headers },
    cookies: {},
    ip: overrides.ip || `127.0.0.${Math.floor(Math.random() * 200) + 1}`,
    ...overrides,
  };
}

const tests = [];
function test(name, fn) {
  tests.push({ name, fn });
}

test('normal request has zero rule risk', () => {
  const result = analyzeRequest(request({ ip: '10.0.0.1' }));
  assert.strictEqual(result.ruleRisk, 0);
  assert.deepStrictEqual(result.attackTypes, []);
});

test('SQL injection is detected', () => {
  const result = analyzeRequest(request({
    ip: '10.0.0.2',
    query: { q: "' UNION SELECT password FROM users --" },
  }));
  assert(result.attackTypes.includes('SQL_INJECTION'));
  assert(result.ruleRisk >= 70);
});

test('sensitive password values are not scanned as attack payloads', () => {
  const result = analyzeRequest(request({
    ip: '10.0.0.3',
    originalUrl: '/api/v1/login',
    path: '/login',
    body: { email: 'user@example.com', password: "' OR 1=1 --" },
  }));
  assert(!result.attackTypes.includes('SQL_INJECTION'));
});

test('authenticated admin route is not treated as admin enumeration', () => {
  const result = analyzeRequest(request({
    ip: '10.0.0.4',
    originalUrl: '/api/v1/admin/users',
    path: '/admin/users',
    evoGateIdentity: { role: 'admin' },
  }));
  assert(!result.attackTypes.includes('ADMIN_ENUMERATION'));
});

test('anonymous admin probe is detected', () => {
  const result = analyzeRequest(request({
    ip: '10.0.0.5',
    originalUrl: '/api/v1/admin/users',
    path: '/admin/users',
  }));
  assert(result.attackTypes.includes('ADMIN_ENUMERATION'));
});

test('brute-force detector reaches configured threshold', () => {
  const ip = '10.0.0.6';
  bruteForceDetector.clearAttempts(ip);
  for (let i = 0; i < 5; i += 1) bruteForceDetector.recordFailedAttempt(ip);
  const result = bruteForceDetector.checkBruteForce(ip);
  assert.strictEqual(result.detected, true);
  assert.strictEqual(result.attackType, 'BRUTE_FORCE');
  bruteForceDetector.clearAttempts(ip);
});

test('progressive risk combines existing and current signals', () => {
  const result = calculateProgressiveRisk({ existingRisk: 20, ruleRisk: 30, lastUpdated: new Date() });
  assert.strictEqual(result.totalRisk, 50);
});

test('progressive risk applies time decay', () => {
  const now = new Date('2026-10-05T12:05:00Z');
  const result = calculateProgressiveRisk({
    existingRisk: 20,
    ruleRisk: 0,
    lastUpdated: new Date('2026-10-05T12:00:00Z'),
    now,
  });
  assert.strictEqual(result.timeDecay, 5);
  assert.strictEqual(result.totalRisk, 15);
});

test('decision engine exposes all intended response tiers', () => {
  assert.strictEqual(makeDecision({ riskScore: 10 }).action, 'ALLOW');
  assert.strictEqual(makeDecision({ riskScore: 25 }).action, 'MONITOR');
  assert.strictEqual(makeDecision({ riskScore: 50 }).action, 'RATE_LIMIT');
  assert.strictEqual(makeDecision({ riskScore: 70, signals: ['SQL_INJECTION'] }).action, 'REDIRECT');
  assert.strictEqual(makeDecision({ riskScore: 85 }).action, 'BLOCK');
});

let failed = 0;
for (const { name, fn } of tests) {
  try {
    fn();
    console.log(`PASS: ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL: ${name}`);
    console.error(error.stack || error.message);
  }
}

if (failed) {
  console.error(`\n${failed} security test(s) failed.`);
  process.exit(1);
}

console.log(`\nAll ${tests.length} security tests passed.`);
